//
//  TextureLoad.h
//  Test02
//
//  Created by Моноблок on 10.04.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef TextureLoad_h
#define TextureLoad_h

#include <OpenGLES/ES1/gl.h>

GLuint TextureLoad(const char *fileName, float &width, float &height);

const char * MakePath(const char *fileName);

#endif
