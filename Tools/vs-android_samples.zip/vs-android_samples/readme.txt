vs-android Sample Projects
==========================

These sample projects are from the Android NDK. The NDK can be downloaded here:
http://developer.android.com/sdk/ndk/index.html



VS Projects
===========

The solution and project files included in this archive will compile under Visual
Studio 2010, using vs-android v0.9 or higher.

They can be located in any directory, and will compile fine as-is.

Please note that the 'hello-gl2' sample will not run on an Android virtual device.
You'll need recent hardware instead to run that sample.




License
=======

vs-android is released under the zlib license.
http://en.wikipedia.org/wiki/Zlib_License

Copyright (c) 2012 Gavin Pugh http://www.gavpugh.com/
